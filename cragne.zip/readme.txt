To play this .gblorb file, you will need an application called an "interpreter."

One very good intepreter is Lectrote, available on many platforms. (For modern Mac OSes, it's basically your only reliable option!) https://github.com/erkyrath/lectrote/releases

Learn more about interpreters at the Interactive Fiction Wiki: http://ifwiki.org/index.php/Interpreter

On behalf of all eighty-something of us: Thank you for playing Cragne Manor.